var gulp = require('gulp');
var gulp_sass = require('gulp-sass');
var file_include = require('gulp-file-include');
var browser_sync = require('browser-sync').create();

// html browser_sync
gulp.task("html", function(){
    gulp.src(["./*.html"])
    .pipe(file_include())
    .pipe(gulp.dest("./public"))
    .pipe(browser_sync.stream());
});

// sass browser_sync
gulp.task("sass", function(){
    gulp.src(["./sass/style.scss"])
    .pipe(gulp_sass())
    .pipe(gulp.dest("./public/assets/css"))
    .pipe(browser_sync.stream());
});

// js browser_sync
gulp.task("js", function(){
    gulp.src(["./assets/js/*.js"])
    .pipe(gulp.dest("./public/assets/js"))
    .pipe(browser_sync.stream());
});

// copy images
gulp.task("image", function(){
    gulp.src(["./assets/images/*.png", "./assets/images/*.jpg"])
    .pipe(gulp.dest("./public/assets/images"));
});

// copy css
gulp.task("copy-css", function(){
    gulp.src([
        "node_modules/owl.carousel/dist/assets/owl.carousel.min.css"
    ])
    .pipe(gulp.dest("./public/assets/css"))
});

// copy js
gulp.task("copy-js", function(){
    gulp.src([
        "node_modules/jquery/public/jquery.min.js",
        "node_modules/owl.carousel/dist/owl.carousel.min.js",
        "node_modules/owl.carousel/docs/assets/vendors/jquery.min.js"
    ])
    .pipe(gulp.dest("./public/assets/js"))
});



// browser sync
gulp.task("browser_sync", ["html", "sass", "image", "js"], function(){
    browser_sync.init({
        server: {
            baseDir: "./public"
        }
    });
    gulp.watch(["./*.html", "./global-html/*.html"], ["html"]);
    gulp.watch(["./sass/*scss"], ["sass"]);
    gulp.watch(["./assets/image/**"], ["image"]);
    gulp.watch(["./assets/js/*.js"], ["js"]);
});

gulp.task("default", ["browser_sync", "copy-css", "copy-js"]);
