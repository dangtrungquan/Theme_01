(function($){

    $(document).ready(function(){
        // slider home
        $('.owl-carousel-header').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            items: 1,
            autoHeight:true,
            navText: [
                '<img src="assets/images/icon-arrow-left-lg.png">',
                '<img src="assets/images/icon-arrow-right-lg.png">'
            ]
        });
        // slider owl-carousel-blogger
        $('.owl-carousel-blogger').owlCarousel({
            loop: true,
            margin: 34,
            nav: true,
            autoHeight:true,
            responsive : {
                // breakpoint from 0 up
                0 : {
                    items: 2
                },
                // breakpoint from 480 up
                480 : {
                    items: 4
                },
                // breakpoint from 768 up
                768 : {
                    items: 6
                }
            },
            navText: [
                '<img src="assets/images/icon-arrow-left-lg.png">',
                '<img src="assets/images/icon-arrow-right-lg.png">'
            ]
        });

        // slider owl-carousel-brands
        $('.owl-carousel-brands').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            autoHeight:true,
            responsive : {
                // breakpoint from 0 up
                0 : {
                    items: 2
                },
                // breakpoint from 480 up
                480 : {
                    items: 4
                },
                // breakpoint from 768 up
                768 : {
                    items: 6
                }
            },
            navText: [
                '<img src="assets/images/icon-arrow-left-lg.png">',
                '<img src="assets/images/icon-arrow-right-lg.png">'
            ]
        });
    });

})(jQuery);
